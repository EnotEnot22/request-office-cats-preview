/* Cell Field — adapted from the user's Originkit source.
   Same nearest-two-seeds cell field; REQUEST palette, bounded 30fps canvas,
   no dependencies. Pauses offscreen, in hidden tabs and for reduced motion. */
(() => {
  const canvas = document.querySelector('#cell-field');
  const host = document.querySelector('.hero-art');
  const toggle = document.querySelector('.motion-toggle');
  if (!canvas || !host) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let width = 0, height = 0, frame = 0, last = 0, active = true, paused = false;
  let pointer = null, grip = 0, seeds = [];
  function resize() {
    const box = canvas.getBoundingClientRect();
    width = box.width; height = box.height;
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // Stable seeds avoid jumping between a paused render and animation.
    seeds = Array.from({length:12}, (_,i) => ({
      x: ((i * .6180339887 + .17) % 1) * width,
      y: ((i * .3819660113 + .29) % 1) * height,
      vx: Math.cos(i * 2.4) * 22, vy: Math.sin(i * 2.4) * 22,
      tint: (i * .6180339887) % 1
    }));
    draw(0);
  }
  function draw(dt) {
    ctx.clearRect(0, 0, width, height);
    grip += ((pointer ? 1 : 0) - grip) * Math.min(1, dt * 5);
    for (const s of seeds) {
      s.x += s.vx * dt; s.y += s.vy * dt;
      if (s.x < 0 || s.x > width) s.vx *= -1;
      if (s.y < 0 || s.y > height) s.vy *= -1;
      s.x = Math.max(0, Math.min(width, s.x)); s.y = Math.max(0, Math.min(height, s.y));
    }
    const step = width < 500 ? 18 : 17;
    for (let y = 0; y < height; y += step) for (let x = 0; x < width; x += step) {
      let best = Infinity, second = Infinity, tint = 0;
      for (const s of seeds) {
        const d = (x-s.x)**2 + (y-s.y)**2;
        if (d < best) { second = best; best = d; tint = s.tint; }
        else if (d < second) second = d;
      }
      if (pointer && grip > .02) {
        const d = ((x-pointer.x)**2 + (y-pointer.y)**2) / (1.5 * grip);
        if (d < best) { second = best; best = d; } else if (d < second) second = d;
      }
      const d1 = Math.sqrt(best), d2 = Math.sqrt(second);
      const own = d1+d2 > .001 ? (d2-d1)/(d2+d1) : 1;
      const solid = Math.min(1, own / .42);
      // Only the established accent and neutral foreground, no second green.
      ctx.fillStyle = tint < .45 ? `rgba(1,230,168,${.12+solid*.65})` : `rgba(236,236,236,${.1+solid*.55})`;
      ctx.beginPath(); ctx.arc(x,y,3.1*(.45+solid*.75),0,Math.PI*2); ctx.fill();
    }
  }
  function loop(now) {
    frame = 0;
    if (!active || paused || reduced.matches || document.hidden) return;
    if (now-last >= 33) { draw(Math.min((now-last)/1000,.05)); last = now; }
    frame = requestAnimationFrame(loop);
  }
  function sync() {
    cancelAnimationFrame(frame); frame = 0; last = performance.now();
    canvas.dataset.motion = paused || reduced.matches ? 'paused' : active && !document.hidden ? 'running' : 'idle';
    if (active && !paused && !reduced.matches && !document.hidden) frame = requestAnimationFrame(loop);
    toggle.setAttribute('aria-pressed', String(paused));
    toggle.textContent = paused ? 'Включить анимацию' : 'Остановить фон';
    toggle.hidden = reduced.matches;
  }
  host.addEventListener('pointermove', e => {
    const r = canvas.getBoundingClientRect(); pointer = {x:e.clientX-r.left,y:e.clientY-r.top};
  });
  host.addEventListener('pointerleave', () => { pointer = null; });
  new ResizeObserver(resize).observe(host);
  new IntersectionObserver(([entry]) => {active = entry.isIntersecting; sync();}).observe(host);
  document.addEventListener('visibilitychange',sync);
  reduced.addEventListener('change', sync);
  document.documentElement.classList.add('cell-ready');
  toggle.addEventListener('click', () => {paused = !paused; sync();});
  resize(); sync();
})();
